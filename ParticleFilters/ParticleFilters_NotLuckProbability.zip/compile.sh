g++ -c -O3 ParticleFilters.c
g++  *.o -O3 -g -lGL -lGLU -lglut -no-pie -o ParticleFilters

